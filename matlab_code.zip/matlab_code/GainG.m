%% Define data for all tests
% SE Data
frequency_SE = [0.5, 1, 1.5, 3, 10, 16, 20, 50, 100, 220, 300, 360, 400, 450, 490, 500, 550, 800, 1000];
%Output_SE = [0.292, 0.686, 1.029, 1.499, 1.767, 2.03, 2.04, 1.96, 2.07, 1.92, 1.65, 1.52, 1.40, 1.328, 1.219, 1.190, 1.044, 0.723, 0.386];
Output_SE = [0.003685 0.019797 0.044678 0.162779 0.872081 1.408780 1.565151 1.936534 2.125095 1.969346 1.959754 1.725589 1.677274 1.592505 1.345731 1.316043 1.163543 0.649643 0.448191];


Gain_dB_SE = 20*log10((Output_SE/0.002));

% FD Data
frequency_FD = [1,2,5,10,13,15,17,20,50,100,200,440,450,500,550, 800, 1000];
Output_FD = [0.124,0.241,0.508, 0.900,1.09,1.14,1.16,1.28,1.49,1.75,1.83,1.33,1.29,1.23,1.05,0.798, 0.687];
Gain_dB_FD = 20*log10((Output_FD/0.002));

% DD Data
frequency_DD = [1,2,5,10,13,15,17,20,50,100,200,450,490,500,550,800, 1000];
output_DD = [0.104, 0.209,0.611,0.908, 1.143,1.062,1.143,1.250,1.313,1.452,1.542,1.292,1.194,1.069,1.055, 0.754, 0.622];
gain_dB_DD = 20*log10(output_DD/0.002);

% %% Create a figure for combined plot
% figure;
% 
% % Plotting all three sets of data
% semilogx(frequency_SE, Gain_dB_SE, 'b-', 'LineWidth', 2); hold on;
% semilogx(frequency_FD, Gain_dB_FD, 'r-', 'LineWidth', 2); 
% semilogx(frequency_DD, gain_dB_DD, 'g-', 'LineWidth', 2);
% 
% % Labels and legend
% xlabel('Frequency (Hz)');
% ylabel('Gain (dB)');
% title('Differential Mode Bode Plots');
% legend('SE', 'FD', 'DD');
% xlim([1,1000]);
%% 设定CSV文件路径
filenameSE = 'C:\Users\yyyyds\Documents\LTspice\SE_AD8226DMG.csv';

% 读取CSV文件
dataSE = readtable(filenameSE);

% 将表格数据转换为数组，如果需要
frequenciesSE = table2array(dataSE(:, 'Frequency'));
gainsSE = table2array(dataSE(:, 'Gain_dB_'));
disp(frequenciesSE);
disp(gainsSE);

% 设定CSV文件路径
filenameFD = 'C:\Users\yyyyds\Documents\LTspice\FDA_AD8604DMG.csv';

% 读取CSV文件
dataFD = readtable(filenameFD);

% 将表格数据转换为数组，如果需要
frequenciesFD = table2array(dataFD(:, 'Frequency'));
gainsFD = table2array(dataFD(:, 'Gain_dB_'));
disp(frequenciesFD);
disp(gainsFD);

% 设定CSV文件路径
filenameDD = 'C:\Users\yyyyds\Documents\LTspice\DDA_AD8604DMG.csv';

% 读取CSV文件
dataDD = readtable(filenameDD);

% 将表格数据转换为数组，如果需要
frequenciesDD = table2array(dataDD(:, 'Frequency'));
gainsDD = table2array(dataDD(:, 'Gain_dB_'));
disp(frequenciesDD);
disp(gainsDD);


% 设定画图
figure;

yLimits = [30,65]; % 获取当前y轴的限制，以便全高填充
fill([15 15 500 500], [yLimits(1) yLimits(2) yLimits(2) yLimits(1)], [0.9 0.9 0.9], 'EdgeColor', 'none', 'FaceAlpha', 0.5); 
% SE 数据绘制
semilogx(frequency_SE, Gain_dB_SE, 'b-', 'LineWidth', 2); % 实际测试数据，实线
hold on; % 保持画图状态，以便继续在同一张图上绘制
semilogx(frequenciesSE, gainsSE, 'b--', 'LineWidth', 2); % 仿真数据，虚线

% FD 数据绘制
semilogx(frequency_FD, Gain_dB_FD, 'r-', 'LineWidth', 2); % 实际测试数据，实线
semilogx(frequenciesFD, gainsFD, 'r--', 'LineWidth', 2); % 仿真数据，虚线

% DD 数据绘制
semilogx(frequency_DD, gain_dB_DD, 'g-', 'LineWidth', 2); % 实际测试数据，实线
semilogx(frequenciesDD, gainsDD, 'g--', 'LineWidth', 2); % 仿真数据，虚线

% 图例、标题及标签
legend('SE BenchTest', 'SE Simulation', 'FD BenchTest', 'FD Simulation', 'DD BenchTest', 'DD Simulation','Location', 'southeast');
title('Differential Gain for SE, FD, and DD AFEs');
xlabel('Frequency (Hz)');
ylabel('Gain (dB)');
xlim([1, 1000]); % 根据你的数据范围设置
grid on; % 显示网格

hold off; % 结束画图状态
 
% %% % 设定画图
% figure;
% % 保持画图状态，以便继续在同一张图上绘制
% 
% % SE 数据绘制
% semilogx(frequency_SE, Gain_dB_SE, 'b-', 'LineWidth', 2);
% hold on;% 实际测试数据，实线
% semilogx(frequenciesSE, gainsSE, 'b--', 'LineWidth', 2); % 仿真数据，虚线
% 
% % FD 数据绘制
% semilogx(frequency_FD, Gain_dB_FD, 'r-', 'LineWidth', 2); % 实际测试数据，实线
% semilogx(frequenciesFD, gainsFD, 'r--', 'LineWidth', 2); % 仿真数据，虚线
% 
% % DD 数据绘制
% semilogx(frequency_DD, gain_dB_DD, 'g-', 'LineWidth', 2); % 实际测试数据，实线
% semilogx(frequenciesDD, gainsDD, 'g--', 'LineWidth', 2); % 仿真数据，虚线
% 
% % 简化图例
% plot(nan, nan, 'b-', 'LineWidth', 2); % 用于图例的蓝色实线
% plot(nan, nan, 'r-', 'LineWidth', 2); % 用于图例的红色实线
% plot(nan, nan, 'g-', 'LineWidth', 2); % 用于图例的绿色实线
% plot(nan, nan, 'm-', 'LineWidth', 2); % 用于图例的黑色实线（代表BenchTest）
% plot(nan, nan, 'm--', 'LineWidth', 2); % 用于图例的黑色虚线（代表Simulation）
% 
% % 图例、标题及标签
% legend('SE', 'FD', 'DD', 'BenchTest', 'Simulation', 'Location', 'southeast');
% title('Comparison of Gain for SE, FD, and DD AFEs');
% xlabel('Frequency (Hz)');
% ylabel('Gain (dB)');
% xlim([1, 1000]); % 根据你的数据范围设置
% grid on; % 显示网格
% 
% hold off; % 结束画图状态
% 
