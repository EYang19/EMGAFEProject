clear;

INA_SD_Noise_RMS = [0.009, 0.015, 0.02, 0.014, 0.015, 0.018, 0.007, 0.017, 0.018, 0.018];
INA_SD_Active_RMS = [0.609, 0.494, 0.79, 0.646, 0.664, 0.55, 0.591, 0.669, 0.69, 0.578];

FD_Noise_RMS = [0.002, 0.002, 0.002, 0.003, 0.002, 0.002, 0.002, 0.002, 0.002, 0.002];
FD_Active_RMS = [0.351, 0.362, 0.316, 0.315, 0.246, 0.369, 0.386, 0.39, 0.329, 0.431];

DD_Noise_RMS = [0.021, 0.022, 0.019, 0.020, 0.020, 0.019, 0.020, 0.020, 0.021, 0.021];
DD_Active_RMS = [0.434, 0.458, 0.415, 0.475, 0.400, 0.456, 0.434, 0.447, 0.410, 0.415];

DD_SD_Noise_RMS = [0.023, 0.024, 0.021, 0.022, 0.023, 0.023, 0.020, 0.020, 0.020, 0.023];
DD_SD_Active_RMS = [0.834, 0.893, 0.990, 0.913, 0.942, 0.873, 0.941, 0.968, 0.819, 0.952];

% Calculate SNR (SNR = Active RMS / Noise RMS)
INA_SD_SNR = INA_SD_Active_RMS ./ INA_SD_Noise_RMS;
FD_SNR = FD_Active_RMS ./ FD_Noise_RMS;
DD_SNR = DD_Active_RMS ./ DD_Noise_RMS;
DD_SD_SNR = DD_SD_Active_RMS ./ DD_SD_Noise_RMS;

% Convert to dB
INA_SD_SNR_dB = 20 * log10(INA_SD_SNR);
FD_SNR_dB = 20 * log10(FD_SNR);
DD_SNR_dB = 20 * log10(DD_SNR);
DD_SD_SNR_dB = 20 * log10(DD_SD_SNR);

% Compute the means
mean_INA_SD_SNR_dB = mean(INA_SD_SNR_dB);
mean_FD_SNR_dB = mean(FD_SNR_dB);
mean_DD_SNR_dB = mean(DD_SNR_dB);
mean_DD_SD_SNR_dB = mean(DD_SD_SNR_dB);

% Plot bar chart comparing mean SNRs
figure;
bar_data = [mean_INA_SD_SNR_dB, mean_FD_SNR_dB, mean_DD_SNR_dB, mean_DD_SD_SNR_dB];
bar(bar_data);

% Set x-axis labels
xticks([1 2 3 4]);
xticklabels({'INA SD SNR (dB)', 'FD SNR (dB)', 'DD SNR (dB)', 'SD output of DD SNR (dB)'});

% Add title and labels
ylabel('SNR (dB)');
title('Comparison of SNR between SD, FD and DD');
grid on;

% Display specific SNR values
fprintf('Mean SNR for INA SD (dB): %.4f\n', mean_INA_SD_SNR_dB);
fprintf('Mean SNR for FD (dB): %.4f\n', mean_FD_SNR_dB);
fprintf('Mean SNR for DD (dB): %.4f\n', mean_DD_SNR_dB);

% Combine data for boxplot
SNR_all_dB = [ ...
    INA_SD_SNR_dB(:), ...
    FD_SNR_dB(:), ...
    DD_SNR_dB(:), ...
    DD_SD_SNR_dB(:)
];

% Plot boxplot for SNR distribution
figure;
boxplot(SNR_all_dB, {'INA based SD', 'FD', 'DD', 'SD (of DD)'});
ylabel('SNR (dB)');
title('SNR Distribution Across AFE Types');
grid on;

% Calculate mean and standard deviation
AFE_labels = {'INA based SD', 'FD', 'DD', 'SD (of DD)'};
mean_vals = mean(SNR_all_dB);
std_vals = std(SNR_all_dB);

% Print mean ± standard deviation
fprintf('--- SNR (dB) Summary ---\n');
for i = 1:length(AFE_labels)
    fprintf('%s: Mean = %.2f dB, Std = %.2f dB\n', AFE_labels{i}, mean_vals(i), std_vals(i));
end

% (Optional) Mark mean points on the boxplot
hold on;
for i = 1:4
    plot(i, mean_vals(i), 'o', 'MarkerFaceColor', 'c', 'MarkerSize', 6);  % Cyan dot as mean marker
end
hold off;
