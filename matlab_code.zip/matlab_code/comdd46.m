%% 
% CSV 文件路径
filename = "C:\Users\yyyyds\Documents\LTspice\DDA_AD8604CMG_origin.csv";

% 读取数据（自动忽略标题）
data = readmatrix(filename);

% 提取频率和增益矩阵
freq1 = data(:, 1);
gain_all = data(:, 2:end);

% 绘图
figure;
semilogx(freq1, gain_all, 'LineWidth', 1.2);  % 多列自动绘制多条曲线
grid on;
xlabel('Frequency (Hz)');
ylabel('DMRR (dB)');
title('DMRR versus frequency');

% 添加图例（自动标注 Run 编号 + Bench Test）
num_runs = size(gain_all, 2);
legend_labels = arrayfun(@(i) sprintf('Run %d', i), 1:num_runs, 'UniformOutput', false);
legend(legend_labels, 'Location', 'best');
%% 
% CSV 文件路径
filename = "C:\Users\yyyyds\Documents\LTspice\DDA_AD8604CMG_reproduced.csv";

% 读取数据（自动忽略标题）
data = readmatrix(filename);

% 提取频率和增益矩阵
freq2 = data(:, 1);
gain_all2 = data(:, 2:end);

% 绘图
figure;
semilogx(freq2, gain_all2, 'LineWidth', 1.2);  % 多列自动绘制多条曲线
grid on;
xlabel('Frequency (Hz)');
ylabel('DMRR (dB)');
title('DMRR versus frequency');

% 添加图例（自动标注 Run 编号 + Bench Test）
num_runs = size(gain_all2, 2);
legend_labels = arrayfun(@(i) sprintf('Run %d', i), 1:num_runs, 'UniformOutput', false);
legend(legend_labels, 'Location', 'best');



%% 
% ===== 绘图 =====
figure; hold on;
% 设置颜色
color1 = [0 0.4470 0.7410];   % 蓝色
color2 = [0.8500 0.3250 0.0980]; % 红橙色

% 原始仿真（蓝色实线）
h1 = semilogx(freq1, gain_all, '-', 'LineWidth', 1.2);
set(h1, 'Color', color1);  % 所有线设为蓝色

% 复现仿真（红色虚线）
h2 = semilogx(freq2, gain_all2, '-', 'LineWidth', 1.2);
set(h2, 'Color', color2);  % 所有线设为红橙
% 美化
grid on;
xlabel('Frequency (Hz)');
ylabel('DMRR (dB)');
title('DMRR vs Frequency');

% 简洁图例
l1 = semilogx(nan, nan, '-', 'Color', [0 0.4470 0.7410], 'LineWidth', 1.5);
l2 = semilogx(nan, nan, '-', 'Color', [0.8500 0.3250 0.0980], 'LineWidth', 1.5);
legend([l1 l2], {'Original literature (1% R, 10% C)', 'Reproduced (5% R, varied C)'}, 'Location', 'best');
set(gca, 'XScale', 'log');  % 强制设为对数刻度

hold off;