%% 
% CSV 文件路径
filename = "C:\Users\yyyyds\Documents\LTspice\FDA_AD8604CMG_Origin.csv";

% 读取数据（自动忽略标题）
data = readmatrix(filename);

% 提取频率和增益矩阵
freq1 = data(:, 1);
gain_all1 = data(:, 2:end);

% 绘图
figure;
semilogx(freq1, gain_all1, 'LineWidth', 1.2);  % 多列自动绘制多条曲线
grid on;
xlabel('Frequency (Hz)');
ylabel('Gain (dB)');
title('Common Mode Gain vs Frequency');

% 添加图例（自动标注 Run 编号 + Bench Test）
num_runs = size(gain_all1, 2);
legend_labels = arrayfun(@(i) sprintf('Run %d', i), 1:num_runs, 'UniformOutput', false);
legend_labels{end+1} = 'Benchtop Test';  % 添加实验曲线的图例
legend(legend_labels, 'Location', 'best');
%% 
% CSV 文件路径
filename = "C:\Users\yyyyds\Documents\LTspice\FDA_AD8604CMG_Degraded.csv";

% 读取数据（自动忽略标题）
data = readmatrix(filename);

% 提取频率和增益矩阵
freq2 = data(:, 1);
gain_all2 = data(:, 2:end);

% 绘图
figure;
semilogx(freq2, gain_all2, 'LineWidth', 1.2);  % 多列自动绘制多条曲线
grid on;
xlabel('Frequency (Hz)');
ylabel('Gain (dB)');
title('Common Mode Gain vs Frequency');

% 添加图例（自动标注 Run 编号 + Bench Test）
num_runs = size(gain_all2, 2);
legend_labels = arrayfun(@(i) sprintf('Run %d', i), 1:num_runs, 'UniformOutput', false);
legend_labels{end+1} = 'Benchtop Test';  % 添加实验曲线的图例
legend(legend_labels, 'Location', 'best');


%% Plot with simplified legend (line type only)

% ===== 读取同型号数据 =====
filename1 = "C:\Users\yyyyds\Documents\LTspice\FDA_AD8604CMG_Origin.csv";
data1 = readmatrix(filename1);
freq1 = data1(:, 1);
gain_all1 = data1(:, 2:end);
num_runs1 = size(gain_all1, 2);

% ===== 读取失配数据 =====
filename2 = "C:\Users\yyyyds\Documents\LTspice\FDA_AD8604CMG_Degraded.csv";
data2 = readmatrix(filename2);
freq2 = data2(:, 1);
gain_all2 = data2(:, 2:end);
num_runs2 = size(gain_all2, 2);

% ===== 绘图设置 =====
colors = lines(max(num_runs1, num_runs2));
figure; hold on;

% 绘制同型号（实线）
for i = 1:num_runs1
    semilogx(freq1, gain_all1(:, i), '-', 'LineWidth', 1.5, 'Color', colors(i, :));
end

% 绘制失配型号（虚线） 
for i = 1:num_runs2
    semilogx(freq2, gain_all2(:, i), '--', 'LineWidth', 1.5, 'Color', colors(i, :));
end

% ===== 添加简洁图例 =====
h1 = plot(nan, nan, '-', 'Color', 'k', 'LineWidth', 1.5);  % 虚拟线段用于图例
h2 = plot(nan, nan, '--', 'Color', 'k', 'LineWidth', 1.5);
legend([h1 h2], {'Same OpAmp', 'Mismatched OpAmp'}, 'Location', 'best');

% ===== 图形属性 =====
grid on;
xlabel('Frequency (Hz)');
ylabel('Gain (dB)');
title('Common Mode Gain vs Frequency');
hold off;
%% benchtop common mode gain
frequency_FD = [1,2,5,10,13,15,17,20,50,100,200,440,450,500,550,800,1000];
Output_FD_com = [4.25400000000000	5.24500000000000	2.30100000000000	1.18100000000000	0.939700000000000	0.793100000000000	0.677300000000000	0.530600000000000	0.193600000000000	0.181200000000000	0.124400000000000	0.0869800000000000	0.0838600000000000	0.0622700000000000	0.071630000000000	0.174300000000000	0.255800000000000];
Gain_dB_FD_com = 20*log10(((Output_FD_com*0.001)./3.2));

% 图一：共模增益
figure
semilogx(frequency_FD, Gain_dB_FD_com, 'LineWidth', 1.5);
grid on;
xlabel('Frequency (Hz)');
ylabel('Gain (dB)');
title('Common Mode Gain of Fully differential AFE');

% 图二：CMRR
Output_FD = [0.124,0.241,0.508,0.900,1.09,1.14,1.16,1.28,1.49,1.75,1.83,1.33,1.29,1.23,1.05,0.798,0.687];
Gain_dB_FD = 20*log10((Output_FD/0.002));
CMRR_FDD = Gain_dB_FD - Gain_dB_FD_com;

figure
semilogx(frequency_FD, CMRR_FDD, 'LineWidth', 1.5);
grid on;
xlabel('Frequency (Hz)');
ylabel('CMRR (dB)');
title('Benchtop Test CMRR of Fully differential AFE');


