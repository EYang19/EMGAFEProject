% 读取频率数据
freq_table = readtable("F:\project I\CMGdata331\SE\BODE_FREQ.CSV");
freq = freq_table{:, 2};  % 第二列是 Frequency in Hz

% 读取增益数据
gain_table = readtable("F:\project I\CMGdata331\SE\BODE_GAIN.CSV");
gain = gain_table{:, 2};  % 第二列是 Gain in dB

% 检查数据是否对齐
if length(freq) ~= length(gain)
    error('Frequency and Gain data lengths do not match!');
end

% 绘图
figure;
semilogx(freq, gain, '-o', 'LineWidth', 1.5);
grid on;
xlabel('Frequency (Hz)');
ylabel('Gain (dB)');
title('Gain vs Frequency');

%% 
% CSV 文件路径
filename = "C:\Users\yyyyds\Documents\LTspice\SE_AD8226CMG_converted.csv";

% 读取数据（自动忽略标题）
data = readmatrix(filename);

% 提取频率和增益矩阵
freq1 = data(:, 1);
gain_all = data(:, 2:end);

% 绘图
figure;
semilogx(freq1, gain_all, 'LineWidth', 1.2);  % 多列自动绘制多条曲线
grid on;
hold on;
semilogx(freq, gain, '-o', 'LineWidth', 1.5);
xlabel('Frequency (Hz)');
ylabel('Gain (dB)');
title('Common Mode Gain vs Frequency');

% 添加图例（自动标注 Run 编号 + Bench Test）
num_runs = size(gain_all, 2);
legend_labels = arrayfun(@(i) sprintf('Run %d', i), 1:num_runs, 'UniformOutput', false);
legend_labels{end+1} = 'Benchtop Test';  % 添加实验曲线的图例
legend(legend_labels, 'Location', 'best');

%% 
% === 1. 读取差模增益（单 run） ===
diff_gain_table = readtable("C:\Users\yyyyds\Documents\LTspice\SE_AD8226DMG.csv");

% 提取频率和 Gain 列（单位：dB）
freq_dm = diff_gain_table{:, 1};
gain_dm_single = diff_gain_table{:, 2};

% === 2. 假设之前你已读取 gain_all (共模增益) 和 freq1 ===
% 检查频率是否匹配
% if ~isequal(freq1, freq_dm)
%     error('Frequency vectors for DM and CM gain do not match!');
% end

% === 3. 计算 CMRR ===
% 每个 Monte Carlo run：CMRR = DM - CM（单位 dB）
cmrr_all = gain_dm_single - gain_all;  % 自动广播减法

% === 4. 绘图 ===
figure;
semilogx(freq1, cmrr_all, 'LineWidth', 1.2);
grid on;
xlabel('Frequency (Hz)');
ylabel('CMRR (dB)');
title('CMRR for Monte Carlo Runs vs Single DM Measurement');

% 添加图例
num_runs = size(cmrr_all, 2);
legend_labels = arrayfun(@(i) sprintf('Run %d', i), 1:num_runs, 'UniformOutput', false);
legend(legend_labels, 'Location', 'best');


%% 
% 差模输出电压 (V)，对应 frequency_SE 的频率点
Output_SE = [0.003685, 0.019797, 0.044678, 0.162779, 0.872081, ...
             1.408780, 1.565151, 1.936534, 2.125095, 1.969346, ...
             1.959754, 1.725589, 1.677274, 1.592505, 1.345731, ...
             1.316043, 1.163543, 0.649643, 0.448191];

% 差模输出对应的频率 (Hz)
frequency_SE = [0.5, 1, 1.5, 3, 10, 16, 20, 50, 100, ...
                220, 300, 360, 400, 450, 490, 500, 550, 800, 1000];

% 输入信号电压 (V)
Vin = 2e-3;  % 2 mV

% 差模增益 (V/V)
gain_dm_linear = Output_SE / Vin;

% 差模增益 (dB)
gain_dm_dB = 20 * log10(gain_dm_linear);

% 共模频率点 (Hz) - 与共模增益数据一一对应
freq_cm1 = [10, 12.59, 15.85, 19.95, 25.12, 31.62, 39.81, 50.12, 63.10, 79.43, ...
           100, 125.9, 158.5, 199.5, 251.2, 316.2, 398.1, 501.2, 631.0, 794.3, 1000];

% 共模增益 (dB) - 注意：这些是你提供的负值，表示强烈抑制
gain_cm_bench = [-8.10, -9.13, -10.6, -12.3, -14.9, -16.8, -18.1, -20.0, -21.3, -22.6, ...
                 -23.8, -24.6, -25.1, -25.1, -25.0, -24.9, -24.7, -25.5, -26.5, -28.5, -31.5];

% 插值差模增益到共模频率点
gain_dm_interp_dB = interp1(frequency_SE, gain_dm_dB, freq_cm1, 'pchip');

% 计算 CMRR (dB)
cmrr_bench = gain_dm_interp_dB - gain_cm_bench;

% 绘图
figure;
semilogx(freq_cm1, cmrr_bench, '-or', 'LineWidth', 1.5);
grid on;
xlabel('Frequency (Hz)');
ylabel('CMRR (dB)');
title('Bench Test CMRR (Differential vs Common Mode)');

%% 
% Monte Carlo 曲线（每列是一个 run）
figure;
semilogx(freq1, cmrr_all, 'Color', [0.8 0.8 0.8], 'LineWidth', 1.0);  % 灰色仿真线
hold on;

% Bench test CMRR 曲线（红色加粗）
semilogx(freq_cm1, cmrr_bench, '-or', 'LineWidth', 2.0);

% 图形设置
grid on;
xlabel('Frequency (Hz)');
ylabel('CMRR (dB)');
title('CMRR from Simulation and Benchtop Test');

% 图例设置
num_runs = size(cmrr_all, 2);
legend_labels = arrayfun(@(i) sprintf('Run %d', i), 1:num_runs, 'UniformOutput', false);
legend_labels{end+1} = 'Benchtop Test';
legend(legend_labels, 'Location', 'best');


