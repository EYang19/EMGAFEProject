%% ====== 1. 设置 CSV 文件路径 ======
filenameSE = "C:\Users\yyyyds\Documents\LTspice\SE_AD8226DMG.csv";
filenameFD = "C:\Users\yyyyds\Documents\LTspice\FDA_AD8604DMG.csv";
filenameDD = "C:\Users\yyyyds\Documents\LTspice\DDA_AD8604DMG.csv";

%% ====== 2. 读取数据 ======
dataSE = readtable(filenameSE);
dataFD = readtable(filenameFD);
dataDD = readtable(filenameDD);

frequenciesSE = table2array(dataSE(:, 'Frequency'));
gainsSE = table2array(dataSE(:, 'Gain_dB_'));
phasesSE = table2array(dataSE(:, 'Phase_degrees_'));

frequenciesFD = table2array(dataFD(:, 'Frequency'));
gainsFD = table2array(dataFD(:, 'Gain_dB_'));
phasesFD = table2array(dataFD(:, 'Phase_degrees_'));

frequenciesDD = table2array(dataDD(:, 'Frequency'));
gainsDD = table2array(dataDD(:, 'Gain_dB_'));
phasesDD = table2array(dataDD(:, 'Phase_degrees_'));

%% ====== 3. 画增益图（含阴影区域） ======
figure;
yLimits = [30, 65];
fill([15 15 500 500], [yLimits(1) yLimits(2) yLimits(2) yLimits(1)], ...
    [0.9 0.9 0.9], 'EdgeColor', 'none', 'FaceAlpha', 0.5); 
hold on;

% 实际测试数据（假设你有 frequency_SE、Gain_dB_SE 等变量）
semilogx(frequency_SE, Gain_dB_SE, 'b-', 'LineWidth', 2);
semilogx(frequenciesSE, gainsSE, 'b--', 'LineWidth', 2);

semilogx(frequency_FD, Gain_dB_FD, 'r-', 'LineWidth', 2);
semilogx(frequenciesFD, gainsFD, 'r--', 'LineWidth', 2);

semilogx(frequency_DD, gain_dB_DD, 'g-', 'LineWidth', 2);
semilogx(frequenciesDD, gainsDD, 'g--', 'LineWidth', 2);

legend('SE BenchTest', 'SE Simulation', ...
       'FD BenchTest', 'FD Simulation', ...
       'DD BenchTest', 'DD Simulation', 'Location', 'southeast');
title('Differential Gain for SE, FD, and DD AFEs');
xlabel('Frequency (Hz)');
ylabel('Gain (dB)');
xlim([1, 1000]);
grid on;
hold off;

%% ====== 4. 计算并画 Group Delay 图 ======

% 转换为弧度
phaseRadSE = deg2rad(phasesSE);
phaseRadFD = deg2rad(phasesFD);
phaseRadDD = deg2rad(phasesDD);

% 角频率 ω = 2πf
omegaSE = 2 * pi * frequenciesSE;
omegaFD = 2 * pi * frequenciesFD;
omegaDD = 2 * pi * frequenciesDD;

% Group Delay = -d(φ)/d(ω)
groupDelaySE = -diff(phaseRadSE) ./ diff(omegaSE);
groupDelayFD = -diff(phaseRadFD) ./ diff(omegaFD);
groupDelayDD = -diff(phaseRadDD) ./ diff(omegaDD);

% 补偿频率坐标（中值点）
freqSE_mid = (frequenciesSE(1:end-1) + frequenciesSE(2:end)) / 2;
freqFD_mid = (frequenciesFD(1:end-1) + frequenciesFD(2:end)) / 2;
freqDD_mid = (frequenciesDD(1:end-1) + frequenciesDD(2:end)) / 2;

% 绘图
figure;
semilogx(freqSE_mid, groupDelaySE * 1e3, 'b--', 'LineWidth', 2); hold on;
semilogx(freqFD_mid, groupDelayFD * 1e3, 'r--', 'LineWidth', 2);
semilogx(freqDD_mid, groupDelayDD * 1e3, 'g--', 'LineWidth', 2);

legend('INA-SD Simulation', 'FD Simulation', 'DD Simulation', 'Location', 'northwest');
title('Group Delay of INA-SD, FD, and DD AFEs');
xlabel('Frequency (Hz)');
ylabel('Group Delay (ms)');
xlim([1, 1000]);
grid on;
