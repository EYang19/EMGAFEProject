% 定义数据 (每个AFE有两组数据，每组10个样本)
SE_RMS = [0.028, 0.029, 0.023, 0.038, 0.048, 0.083, 0.024, 0.03, 0.051, 0.06;
          0.059, 0.05, 0.053, 0.03, 0.06, 0.043, 0.043, 0.063, 0.038, 0.046]';

FD_RMS = [0.028, 0.056, 0.059, 0.018, 0.02, 0.017, 0.046, 0.028, 0.012, 0.019;
          0.045, 0.044, 0.059, 0.042, 0.051, 0.067, 0.041, 0.039, 0.047, 0.048]';

DD_RMS = [0.024, 0.023, 0.019, 0.021, 0.02, 0.018, 0.022, 0.023, 0.023, 0.021;
          0.022, 0.02, 0.017, 0.013, 0.021, 0.02, 0.016, 0.022, 0.02, 0.025]';

% 合并数据用于绘制箱线图
data = [SE_RMS(:), FD_RMS(:), DD_RMS(:)];

% 绘制箱线图
figure;
boxplot(data, {'INA-SD', 'FD', 'DD'},'Symbol', '');
ylabel('RMS Value/mV');
xlabel('AFE Type');
title('Comparison of Cross-talk RMS Across Different AFE Designs');
grid on;

% 计算均值
mean_SE = mean(SE_RMS, 'all');
mean_FD = mean(FD_RMS, 'all');
mean_DD = mean(DD_RMS, 'all');

% 输出均值
fprintf('Mean RMS Value for SE: %.4f\n', mean_SE);
fprintf('Mean RMS Value for FD: %.4f\n', mean_FD);
fprintf('Mean RMS Value for DD: %.4f\n', mean_DD);
