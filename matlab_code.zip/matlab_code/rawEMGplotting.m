% INA SD
% plotEMG.m
%
% 说明:
% 本脚本用于读取 emg_data.csv 文件中的肌电信号并绘图。
% 假设:
%   - CSV 文件的前 4 行是表头，从第 5 行开始是数值数据；
%   - 第 1 列为时间戳，第 2 列为肌电信号。
clear;
% 设置 CSV 文件名
filename = "C:\Users\yyyyds\Downloads\finalll\INASEraw.csv";

% 读取 CSV 文件，并跳过前 4 行表头
data = readmatrix(filename, 'NumHeaderLines', 4);

% 提取时间戳和肌电信号
time = data(:, 1);        % 第一列：时间
emg_signal = data(:, 2);  % 第二列：肌电信号

% 绘制肌电信号随时间的波形
figure;
plot(time, emg_signal, 'k-');  % 以蓝色线条绘制
hold on;
 xlim([0.00 1.26]);
ylim([-3,3]);
xlabel('time(s)');
ylabel('Amplitude(mV)');
title('Raw surface EMG signal recorded by INA based SD AFE');
grid on;

%% FD
% plotEMG.m
%
% 说明:
% 本脚本用于读取 emg_data.csv 文件中的肌电信号并绘图。
% 假设:
%   - CSV 文件的前 4 行是表头，从第 5 行开始是数值数据；
%   - 第 1 列为时间戳，第 2 列为肌电信号。
clear;
% 设置 CSV 文件名
filename = "C:\Users\yyyyds\Downloads\finalll\FDraw.csv";

% 读取 CSV 文件，并跳过前 4 行表头
data = readmatrix(filename, 'NumHeaderLines', 4);

% 提取时间戳和肌电信号
time = data(:, 1);        % 第一列：时间
emg_signal = data(:, 2)*1000/847;  % 第二列：肌电信号

% 绘制肌电信号随时间的波形
figure;
plot(time, emg_signal, 'k-');  % 以蓝色线条绘制
hold on;
xlim([0.00 1.00]);
ylim([-3 3]);
xlabel('time(s)');
ylabel('Amplitude(mV)');
title('Raw surface EMG signal recorded by Fully differential AFE');
grid on;
%% DD
% plotEMG.m
%
% 说明:
% 本脚本用于读取 emg_data.csv 文件中的肌电信号并绘图。
% 假设:
%   - CSV 文件的前 4 行是表头，从第 5 行开始是数值数据；
%   - 第 1 列为时间戳，第 2 列为肌电信号。
clear;
% 设置 CSV 文件名
filename = "C:\Users\yyyyds\Downloads\finalll\DDraw.csv";

% 读取 CSV 文件，并跳过前 4 行表头
data = readmatrix(filename, 'NumHeaderLines', 4);

% 提取时间戳和肌电信号
time = data(:, 1);        % 第一列：时间
emg_signal = data(:, 2)*1000/784.2;  % 第二列：肌电信号

% 绘制肌电信号随时间的波形
figure;
plot(time, emg_signal, 'k-');  % 以蓝色线条绘制
hold on;
xlim([0.25 1.25]);
ylim([-3 3]);
xlabel('time(s)');
ylabel('Amplitude(mV)');
title('Raw surface EMG signal recorded by Double differential AFE');
grid on;

%% SD of DD
% plotEMG.m
%
% 说明:
% 本脚本用于读取 emg_data.csv 文件中的肌电信号并绘图。
% 假设:
%   - CSV 文件的前 4 行是表头，从第 5 行开始是数值数据；
%   - 第 1 列为时间戳，第 2 列为肌电信号。
clear;
% 设置 CSV 文件名
filename = "C:\Users\yyyyds\Downloads\finalll\SDrawofDD.csv";

% 读取 CSV 文件，并跳过前 4 行表头
data = readmatrix(filename, 'NumHeaderLines', 4);

% 提取时间戳和肌电信号
time = data(:, 1);        % 第一列：时间
emg_signal = data(:, 2)*1000/784.2;  % 第二列：肌电信号

% 绘制肌电信号随时间的波形
figure;
plot(time, emg_signal, 'k-');  % 以蓝色线条绘制
hold on;
xlim([0.25 1.25]);
ylim([-3 3]);
xlabel('time(s)');
ylabel('Amplitude(mV)');
title('Raw surface EMG signal recorded by Double differential AFE');
grid on;
%% total
% 统一清空
clear;

% 设置文件路径
files = {
    "C:\Users\yyyyds\Downloads\finalll\INASEraw.csv", ...
    "C:\Users\yyyyds\Downloads\finalll\FDraw.csv", ...
    "C:\Users\yyyyds\Downloads\finalll\DDraw.csv", ...
    "C:\Users\yyyyds\Downloads\finalll\SDrawofDD.csv"
};

% 放大系数（根据不同AFE计算得到的缩放比例）
scales = [1, 1000/847, 1000/784.2, 1000/784.2];

% X轴范围设置
xlims = [
    0.00, 1.26;
    0.00, 1.00;
    0.25, 1.25;
    0, 1
];

% 图标题
titles = {
    'Raw surface EMG signal recorded by INA based SD AFE', ...
    'Raw surface EMG signal recorded by Fully differential AFE', ...
    'Raw surface EMG signal recorded by Double differential AFE', ...
    'Raw surface EMG signal recorded by single differential node of DD AFE'
};

% 开始绘图
figure;
for i = 1:4
    % 读取数据，跳过表头
    data = readmatrix(files{i}, 'NumHeaderLines', 4);
    time = data(:, 1);
    emg_signal = data(:, 2) * scales(i);
    
    % 子图绘制
    subplot(2, 2, i);
    plot(time, emg_signal, 'k-');
    xlim(xlims(i, :));
    ylim([-4, 4]);
    xlabel('Time (s)');
    ylabel('Amplitude (mV)');
    title(titles{i});
    grid on;
end

% sgtitle('Comparison of Raw EMG Signals from Different AFE Designs'); % 总标题

%% clear;

% 读取数据配置
files = {
    "C:\Users\yyyyds\Downloads\finalll\INASEraw.csv", ...
    "C:\Users\yyyyds\Downloads\finalll\FDraw.csv", ...
    "C:\Users\yyyyds\Downloads\finalll\DDraw.csv", ...
    "C:\Users\yyyyds\Downloads\finalll\SDrawofDD.csv"
};

scales = [1, 1000/847, 1000/784.2, 1000/784.2];
xlims = [
    0.00, 1.26;
    0.00, 1.00;
    0.25, 1.25;
    0, 1
];

titles = {
    'INA based SD AFE', ...
    'Fully differential AFE', ...
    'Double differential AFE', ...
    'Raw surface EMG signal recorded by single differential node of DD AFE'
};

% 设置窗口大小
figure('Position', [100, 100, 1200, 600]);  % 宽 1200px，高 600px

% 使用现代 tiledlayout 更整洁
tiledlayout(2,2, 'Padding', 'compact', 'TileSpacing', 'compact');

for i = 1:4
    data = readmatrix(files{i}, 'NumHeaderLines', 4);
    time = data(:, 1);
    emg_signal = data(:, 2) * scales(i);

    nexttile;
    plot(time, emg_signal, 'k-');
    xlim(xlims(i, :));
    ylim([-3.5, 3.5]);
    xlabel('Time (s)');
    ylabel('Amplitude (mV)');
    title(titles{i});
    grid on;
end

% sgtitle('Comparison of Raw EMG Signals from Different AFE Designs');
set(gcf, 'PaperUnits', 'inches', 'PaperPosition', [0 0 10 5]); % 设置打印尺寸
print(gcf, 'my_EMG_plot', '-dpng', '-r300');  % 导出300dpi PNG图像

