import re
import csv

# 文件路径
input_path = r"C:\Users\yyyyds\Documents\LTspice\DDA_AD8604CMG.txt"
output_path = r'C:\Users\yyyyds\Documents\LTspice\DDA_AD8604CMG_reproduced.csv'

# 初始化
runs = []
current_run = []

# 正则表达式
step_pattern = re.compile(r"Step Information: Run=(\d+)")
data_pattern = re.compile(r"([0-9.+-eE]+)\s+\(([-0-9.+eE]+)dB,([-0-9.+eE]+)°\)")

# 读取并处理
with open(input_path, 'r', encoding='ISO-8859-1') as f:
    for line in f:
        if step_pattern.match(line):
            if current_run:
                runs.append(current_run)
                current_run = []
        else:
            match = data_pattern.match(line.strip())
            if match:
                freq = float(match.group(1))
                gain = float(match.group(2))
                phase = float(match.group(3))
                current_run.append((freq, gain, phase))
    if current_run:  # append last
        runs.append(current_run)

# 提取频率作为主轴
frequencies = [row[0] for row in runs[0]]

# 创建 CSV 表头
header = ['Frequency (Hz)'] + [f'Gain_Run{i+1} (dB)' for i in range(len(runs))]

# 写入 CSV 文件
with open(output_path, 'w', newline='') as csvfile:
    writer = csv.writer(csvfile)
    writer.writerow(header)
    for i in range(len(frequencies)):
        row = [f"{frequencies[i]:.6e}"] + [f"{runs[j][i][1]:.3f}" for j in range(len(runs))]
        writer.writerow(row)

print(f"转换成功，输出路径：{output_path}")
