import csv

# 使用原始字符串指定文件路径
file_path = r'C:\Users\yyyyds\Documents\LTspice\SE_AD8226DMG.txt'
output_path = r'C:\Users\yyyyds\Documents\LTspice\SE_AD8226DMG.csv'
# SE_AD8226DMG
# 初始化列表以存储频率、增益和相位
data = []

try:
    # 以ISO-8859-1编码打开文件，这个编码通常对于含有特殊字符的Windows文本文件较为合适
    with open(file_path, 'r', encoding='ISO-8859-1') as file:
        # 跳过文件的头部（如果有）
        next(file)
        # 读取每一行
        for line in file:
            parts = line.strip().split()
            if len(parts) == 2:
                # 提取频率
                frequency = float(parts[0])
                # 提取增益和相位，去除括号和单位
                magnitude_phase = parts[1].strip('()').split(',')
                magnitude = float(magnitude_phase[0][:-2])  # 去除'dB'并转换为浮点数
                phase = float(magnitude_phase[1][:-1])  # 去除'°'并转换为浮点数
                
                # 添加到数据列表
                data.append([f"{frequency:.3f}", f"{magnitude:.3f}", f"{phase:.3f}"])

    # 将数据写入CSV文件
    with open(output_path, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['Frequency', 'Gain (dB)', 'Phase (degrees)'])  # 写入头部
        writer.writerows(data)

    print(f"Data successfully written to {output_path}")

except Exception as e:
    print(f"Error processing the file: {str(e)}")
